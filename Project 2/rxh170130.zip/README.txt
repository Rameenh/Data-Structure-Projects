Rameen Housseini
RXH170130
CS 3345.005 F20

intellij idea community 2020.2.2
Project SDK: Java version 13.0.2


Run >> Edit Configurations >> templates >> main class: P2Driver, Program Arguments: input.txt output.txt, working directory: C:\...\Project3

https://stackoverflow.com/questions/32951846/run-program-from-intellij-with-command-line-file-input

input.txt should be in the Project3 folder

all .java files should be placed in \Project3\src\

instead of ... fill in the directory you put Project3 in


This is assuming you'll be naming the intellij project: "Project3" as I did.

I tested the program with the sample input given in the pdf, all commands came out as expected.



