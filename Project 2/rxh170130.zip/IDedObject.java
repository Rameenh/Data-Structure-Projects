
public interface IDedObject {
    int getID(); //Returns the ID of the object
    String printID(); //Prints the detials of ID
}
